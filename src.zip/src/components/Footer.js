import React from "react";
import "../styles/Footer.css";

function Footer() {
  return <footer className="footer">© 2025 E Infra. All rights reserved.</footer>;
}

export default Footer;
