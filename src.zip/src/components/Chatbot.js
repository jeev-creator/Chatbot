import React, { useState } from "react";
import "../styles/Chatbot.css";

function Chatbot() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const sendMessage = () => {
    if (input.trim()) {
      setMessages([...messages, { text: input, sender: "user" }]);
      setTimeout(() => {
        setMessages((prev) => [...prev, { text: "Hello! How can I help you?", sender: "bot" }]);
      }, 1000);
      setInput("");
    }
  };

  return (
    <div className="chatbot">
      <div className="chat-box">
        {messages.map((msg, index) => (
          <div key={index} className={msg.sender}>{msg.text}</div>
        ))}
      </div>
      <input type="text" value={input} onChange={(e) => setInput(e.target.value)} />
      <button onClick={sendMessage}>Send</button>
    </div>
  );
}

export default Chatbot;
