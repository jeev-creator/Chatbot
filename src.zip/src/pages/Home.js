import React from "react";
import "../styles/Home.css";

function Home() {
  return (
    <section className="home">
      <div className="home-content">
        <h1>Welcome to <span>E Infra</span></h1>
        <h2>Innovative IT Solutions for a Digital Future</h2>
        <p>
          At <strong>E Infra</strong>, we provide top-notch IT solutions to empower businesses 
          with cutting-edge technology. Our expertise spans software development, cloud computing, 
          cybersecurity, and AI-driven solutions to transform your digital presence.
        </p>

        <div className="features">
          <div className="feature-box">
            <h3>🚀 High Performance</h3>
            <p>Optimized solutions for speed and efficiency.</p>
          </div>
          <div className="feature-box">
            <h3>🔒 Secure & Reliable</h3>
            <p>Top-tier security ensuring seamless operations.</p>
          </div>
          <div className="feature-box">
            <h3>🌐 Future-Ready</h3>
            <p>Stay ahead with our innovative IT services.</p>
          </div>
        </div>

       
      </div>
    </section>
  );
}

export default Home;
