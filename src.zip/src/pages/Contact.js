import React from "react";
import "../styles/Contact.css";

function Contact() {
  return (
    <section className="contact">
      <h1>Contact Us</h1>
      <p>Have any questions? We're here to help!</p>

      <div className="contact-container">
        {/* Left: Contact Form */}
        <div className="contact-left">
          
          <form className="contact-form">
            <input type="text" placeholder="Your Name" required />
            <input type="email" placeholder="Your Email" required />
            <textarea placeholder="Your Message" required></textarea>
            <button type="submit">Send Message</button>
          </form>
        </div>

        {/* Right: Contact Details */}
        <div className="contact-right">
          <h2>Reach Us At</h2>
          <p><strong>Email:</strong> contact@einfra.com</p>
          <p><strong>Phone:</strong> +123 456 7890</p>
          <p><strong>Address:</strong> Hustle Hub Tech Park, Bangalore</p>
          <p>We’re available 24/7 to assist you with your IT needs.</p>
        </div>
      </div>
    </section>
  );
}

export default Contact;
