import React from "react";
import "../styles/Services.css";

function Services() {
  return (
    <section className="services">
      <div className="services-content">
        <h1>Our <span>Services</span></h1>
        <p>We offer cutting-edge IT solutions tailored to your business needs.</p>

        <div className="service-list">
          <div className="service-box">
            <h2>🌐 Web Development</h2>
            <p>We create high-performance, responsive, and visually appealing websites that drive user engagement.</p>
          </div>

          <div className="service-box">
            <h2>☁ Cloud Solutions</h2>
            <p>Scalable and secure cloud services to optimize your business operations with efficiency.</p>
          </div>

          <div className="service-box">
            <h2>🔒 Cybersecurity</h2>
            <p>Advanced security solutions to protect your data and prevent cyber threats effectively.</p>
          </div>

          <div className="service-box">
            <h2>🤖 AI & Automation</h2>
            <p>Innovative AI-powered automation solutions to enhance productivity and efficiency.</p>
          </div>
        </div>

      
      </div>
    </section>
  );
}

export default Services;
