import "../styles/About.css";

function About() {
  return (
    <div className="about">
      <div className="about-content">
        <h1>About <span>E Infra</span></h1>
        <p>We are an IT solutions provider focused on delivering cutting-edge technology.</p>

      

      

        

        {/* Why Choose Us Section */}
        <div className="about-why">
          <h2>Why Choose Us?</h2>
          <p>✔ Industry-leading expertise with 10+ years of experience.</p>
          <p>✔ Cutting-edge solutions tailored for your business growth.</p>
          <p>✔ A dedicated team focused on innovation and excellence.</p>
        </div>

   
      </div>
    </div>
  );
}

export default About;
