import React from "react";
import "../styles/Portfolio.css";

const developers = [
  { name: "Rahul Sharma", role: "Full Stack Developer", desc: "Expert in MERN stack and performance optimization." },
  { name: "Priya Patel", role: "Frontend Developer", desc: "UI/UX enthusiast with a passion for clean design." },
  { name: "Amit Verma", role: "Backend Developer", desc: "Skilled in APIs, databases, and security protocols." }
];

function Portfolio() {
  return (
    <section className="portfolio">
      <h1>Meet Our Development Team </h1>
      
      <p>Our talented developers are the backbone of E Infra, ensuring top-notch solutions for our clients.</p>

      <div className="team">
        {developers.map((dev, i) => (
          <div key={i} className="dev-card">
            <h3>{dev.name}</h3>
            <p><strong>{dev.role}</strong></p>
            <p>{dev.desc}</p>
          </div>
        ))}
      </div>

      {/* Additional Expertise Section */}
      <div className="expertise">
        <h2>Our Expertise</h2>
        <p>
          At E Infra, we specialize in building high-performance applications,
          secure cloud solutions, and innovative AI-driven technologies. Our
          team is dedicated to delivering scalable and robust digital products.
        </p>
      </div>

     
    </section>
  );
}

export default Portfolio;
